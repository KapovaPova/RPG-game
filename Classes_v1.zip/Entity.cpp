#include "Entity.h"
#include <iostream>

Entity::Entity() {}
Entity::Entity(int hp, int x, int y, int size_x, int size_y) {
    if (hp <= 0 || x < 0 || y < 0 || size_x <= 0 || size_y <= 0) {
        std::cout << "Incorrect data!" << std::endl;
        print();
        return;
    }
    this->hp = hp;
    this->x = x;
    this->y = y;
    this->size_x = size_x;
    this->size_y = size_y;
}
void Entity::print() {
    std::cout << "hp: " << hp << ", x: " << x << ", y: " << y << ", size_x: " << size_x << ", size_y: " << size_y << std::endl;
}
Entity::~Entity(){}