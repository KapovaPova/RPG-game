#include "Player.h"
#include <iostream>

Player::Player(int hp, int x, int y, int size_x, int size_y, std::map<int, int> effects,
        int ability, int level, std::vector<int> inventory, int money) : Entity(hp, x, y, size_x, size_y) {
    if (hp <= 0 || x < 0 || y < 0 || size_x <= 0 || size_y <= 0 || level < 0 || money < 0) {
        std::cout << "Incorrect data!" << std::endl;
        print();
        return;
    }
    this->effects = effects;
    this->ability = ability;
    this->level = level;
    this->inventory = inventory;
    this->money = money;
}
void Player::print() {
    std::cout << "hp: " << hp << ", x: " << x << ", y: " << y << ", size_x: " << size_x << ", size_y: " << size_y << std::endl;
    std::cout << "effects: " << std::endl;
    for (const std::pair<const int, int> effect : effects) {
        std::cout << "    " << effect.first << " : " << effect.second << " seconds" << std::endl;
    }
    std::cout << "ability: " << ability << ", level: " << level << ", inventory: " << std::endl;
    for (const int item : inventory) {
        std::cout << "    " << item << std::endl;
    }
    std::cout << "money: " << money << std::endl;
}
void Player::move(int x, int y) {
    this->x = x;
    this->y = y;
}
std::pair<int, int> Player::get_position() {
    std::pair<int, int> position(x, y);
    return position;
}
void Player::change_level(int level) {
    this->level = level;
}
int Player::get_level() {
    return level;
}
void Player::change_effects(std::map<int, int> effects) {
    this->effects = effects;
}
std::map<int, int> Player::get_effects() {
    return effects;
}
void Player::change_inventory(std::vector<int> inventory) {
    this->inventory = inventory;
}
std::vector<int> Player::get_inventory() {
    return inventory;
}
void Player::change_money(int money) {
    this->money = money;
}
int Player::get_money() {
    return money;
}