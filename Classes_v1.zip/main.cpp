#include "Player.h"
#include <iostream>
#include <map>
#include <vector>

int main() {
    Entity bullet(100, 0, 0, 1, 1);
    bullet.print();
	std::cout << std::endl;

    std::map<int, int> map1;
    map1[1] = 30;
    map1[2] = 60;
    std::vector<int> inventory;
    inventory.push_back(0);
    inventory.push_back(1);
    Player pl1(10, 0, 0, 1, 1, map1, 0, 0, inventory, 100);
    pl1.print();
    return 0;
}

/*
#include <iostream>
#include <map>
#include <vector>
#include <windows.h>
using namespace std;


class Sell_and_Shop
{
	int purchase_price_axe;
	int sale_price_log;

	map<string, int> axes;

public:

	Sell_and_Shop() {}

	Sell_and_Shop(int s_p_l, int p_p_a)
	{
		purchase_price_axe = p_p_a;
		sale_price_log = s_p_l;
	}

	void Add_Axe(string name, int price)
	{
		axes.insert(make_pair(name, price));
	}

	string Buy_Axe(int& balance_P, string name)
	{
		if (axes.count(name) == 1)
		{
			if (axes[name] >= balance_P)
			{
				balance_P -= axes[name];
			}
		}
	}

	int Sell_logs(int number_logs)
	{
		return number_logs * sale_price_log;
	}

};


//половину понятно, половину нет
class Player
{
	int balance_P = 50; // деньги
	int damage_P;
	int hp_p;

	string name_weapon; // типа какое есть оружие?
	string buy_axe_P; // типа у тебя топор?
	vector<vector<int>> inventory_P; // инвентарь

public:

	Player(string n_v) //присваиваем оружие
	{
		name_weapon = n_v;
	}

	int Get_Damage() // дамаг
	{
		Axe axe_F;
		damage_P = axe_F.getDamage();
	}

	void Get_Inventory(vector<vector<int>> inventory) //инвентарь
	{
		inventory_P = inventory;
	}

	void Buy_Axe() //купить топор
	{
		Sell_and_Shop buy_axe;
		Player(
			buy_axe.Buy_Axe
			(balance_P, buy_axe_P)
		);
	}

	void Sell_Log() // продать дерево
	{
		Sell_and_Shop sell_logs;
		balance_P += sell_logs.Sell_logs(inventory_P[0][0]);
	}

};

// просто топор
class Axe {
	int damage;

public:

	Axe() {}

	Axe(int d)
	{
		damage = d;
	}

	int getDamage() {
		return damage;
	}

};

//класс когото
class Entity
{
	int damage;
	int hp;
	int exp;

public:

	Entity() {}

	Entity(int h, int e) {
		hp = h;
		exp = e;
	}

	//получить опыт
	int getExp() const {
		return exp;
	}
	//получить кол-во здоровья
	int getHp() const {
		return hp;
	}
	//вернуть параметры
	vector<int> Return_Parametres() const {
		vector<int> parametres;

		parametres.push_back(hp);
		parametres.push_back(exp);

		return parametres;
	}

};


/*
log - 1
health potion - 2
power potion - 3
regeneratinon potion - 4
haste potion - 5
loot - 6-9
#1#
/*
void Open_Inventory(vector<vector<int>> inventory)
{
	bool ePressed = false;
	bool _1Pressed = false;
	bool _2Pressed = false;

	bool _3Pressed = false;
	bool _4Pressed = false;

	bool eCurrentlyPressed = (GetAsyncKeyState('E') & 0x8000) != 0;


	if (eCurrentlyPressed && !ePressed)
	{


		Sleep(50);
		if (bool num1CurrentlyPressed = (GetAsyncKeyState('1') & 0x8000) != 0 && !_1Pressed)
		{

			cout << 1;
			_1Pressed = num1CurrentlyPressed;
		}


		else if (bool num2CurrentlyPressed = (GetAsyncKeyState('2') & 0x8000) != 0 && !_2Pressed)
		{

			cout << 2;
			_2Pressed = num2CurrentlyPressed;
		}


		else if (bool num3CurrentlyPressed = (GetAsyncKeyState('3') & 0x8000) != 0 && !_3Pressed)
		{

			cout << 3;
			_3Pressed = num3CurrentlyPressed;
		}


		else if (bool num4CurrentlyPressed = (GetAsyncKeyState('4') & 0x8000) != 0 && !_4Pressed)
		{

			cout << 4;
			_3Pressed = num4CurrentlyPressed;
		}
		Sleep(50);

	}


	ePressed = eCurrentlyPressed;
	Sleep(50);
}


void Battle(/*vector<vector<int>> inventory, int axe_damage, int character_hp, int entity_damage, vector<string> loot, int entity_hp)
{

	while (entity_hp > 0)
	{
		//Open_Inventory()
	}
}
#1#

int main()
{
	//Battle(1);
	Axe axe;
	axe.getDamage();
}
*/
