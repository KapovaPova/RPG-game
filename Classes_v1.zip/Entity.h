#ifndef MAIN_ENTITY_H
#define MAIN_ENTITY_H

class Entity {
protected:
    int hp = 1; // здоровье
    int x = 0; // координата x
    int y = 0; // координата y
    int size_x = 1; // размер объекта по горизонтали
    int size_y = 1; // размер объекта по вертикали
public:
    Entity();
    Entity(int hp, int x, int y, int size_x, int size_y);
    void print();
    ~Entity();
};

#endif //MAIN_ENTITY_H