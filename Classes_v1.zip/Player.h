#ifndef MAIN_PLAYER_H
#define MAIN_PLAYER_H

#include "Entity.h"
#include <map>
#include <vector>

class Player: public Entity {
protected:
    std::map<int, int> effects; // эффекты игрока, ключ: индекс эффекта, значение: сколько осталось эффекту(секунды)
    int ability = 0; // способность игрока, индекс способности
    int level = 0; // уровень игрока
    std::vector<int> inventory; // инвентарь игрока
	int money = 0; // деньги игрока
public:
    Player(int hp, int x, int y, int size_x, int size_y, std::map<int, int> effects,
        int ability, int level, std::vector<int> inventory, int money);
    void print();
    void move(int x, int y);
	std::pair<int, int> get_position();
    void change_level(int level);
	int get_level();
    void change_effects(std::map<int, int> effects);
	std::map<int, int> get_effects();
    void change_inventory(std::vector<int> inventory);
	std::vector<int> get_inventory();
	void change_money(int money);
	int get_money();
};

#endif //MAIN_PLAYER_H