#include "tool.h"

#include <iostream>

tool::tool() {}
tool::tool(int damage, int durability, int price) {
    if (damage < 0 || durability < 0 || price < 0) {
        std::cout << "Incorrect data!" << std::endl;
        print();
        return;
    }
    this->damage = damage;
    this->durability = durability;
    this->price = price;
}

void tool::print() {
    std::cout << "damage: " << damage << ", durability: " << durability << ", price: " << price << std::endl;
}
void tool::change_damage(int damage) {
    this->damage = damage;
}
int tool::get_damage() {
    return damage;
}
void tool::change_durability(int durability) {
    this->durability = durability;
}
int tool::get_durability() {
    return durability;
}
void tool::change_price(int price) {
    this->price = price;
}
int tool::get_price() {
    return price;
}

tool::~tool() {}
