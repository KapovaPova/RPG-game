#include "player.h"
#include "tool.h"

#include <iostream>
#include <map>
#include <vector>

int main() {
	//пример использования класса entity
    entity bullet(100, 0, 0, 1, 1);
    bullet.print();
	std::cout << std::endl;

	//пример использования класса player
    std::map<int, int> map1;
    map1[1] = 30;
    map1[2] = 60;
    std::vector<int> inventory;
    inventory.push_back(0);
    inventory.push_back(1);
    player pl1(10, 0, 0, 1, 1, map1, 0, 0, inventory, 100);
    pl1.print();
	std::cout << std::endl;

	//пример использования класса tool
	tool tl1(10, 10, 10);
	tl1.print();

    return 0;
}