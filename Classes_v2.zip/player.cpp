#include "player.h"

#include <iostream>

player::player(int health, int x, int y, int size_x, int size_y, std::map<int, int> effects,
        int ability, int level, std::vector<int> inventory, int money) : entity(health, x, y, size_x, size_y) {
    if (health <= 0 || x < 0 || y < 0 || size_x <= 0 || size_y <= 0 || ability < 0 || level < 0 || money < 0) {
        std::cout << "Incorrect data!" << std::endl;
        print();
        return;
    }
    this->effects = effects;
    this->ability = ability;
    this->level = level;
    this->inventory = inventory;
    this->money = money;
}

void player::print() {
    std::cout << "health: " << health << ", x: " << x << ", y: " << y << ", size_x: " << size_x << ", size_y: " << size_y << std::endl;
    std::cout << "effects: " << std::endl;
    for (std::pair<const int, int> effect : effects) {
        std::cout << "    " << effect.first << " : " << effect.second << " seconds" << std::endl;
    }
    std::cout << "ability: " << ability << ", level: " << level << ", inventory: " << std::endl;
    for (int item : inventory) {
        std::cout << "    " << item << std::endl;
    }
    std::cout << "money: " << money << std::endl;
}
void player::change_effects(std::map<int, int> effects) {
    this->effects = effects;
}
std::map<int, int> player::get_effects() {
    return effects;
}
int player::get_ability() {
    return ability;
}
void player::change_level(int level) {
    this->level = level;
}
int player::get_level() {
    return level;
}
void player::change_inventory(std::vector<int> inventory) {
    this->inventory = inventory;
}
std::vector<int> player::get_inventory() {
    return inventory;
}
void player::change_money(int money) {
    this->money = money;
}
int player::get_money() {
    return money;
}

player::~player() {}
