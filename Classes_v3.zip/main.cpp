#include "entity/player.h"
#include "item/tool.h"

#include <iostream>
#include <map>
#include <vector>

#include "item/potion.h"

int main() {
	//пример использования класса entity
    entity bullet(100, 0, 0, 1, 1);
    bullet.print();
	std::cout << std::endl;

	//пример использования класса player
    std::map<int, int> map1;
    map1[1] = 30;
    map1[2] = 60;
    std::vector<int> inventory;
    inventory.push_back(0);
    inventory.push_back(1);
    player pl1(10, 0, 0, 1, 1, map1, 0, 0, inventory, 100);
    pl1.print();
	std::cout << std::endl;

	//пример использования класса item
	item it1(0, "pt1");
	it1.print();
	std::cout << std::endl;

	//пример использования класса tool
	std::map<int, int> map2;
	map2[1] = 30;
	map2[2] = 60;
	tool tl1(1, "tl1", 10, 10, 10, 10, map2);
	tl1.print();
	std::cout << std::endl;

	//пример использования класса potion
	potion pt1(2, "pt1", 1);
	pt1.print();

    return 0;
}
